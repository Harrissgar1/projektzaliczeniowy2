﻿using AzureChatApp.Models.Chat;
using Microsoft.EntityFrameworkCore;

namespace AzureChatApp.Models.Database
{
    public class DatabaseManager : IDatabaseManager
    {
        private readonly ChatContext _context;

        public DatabaseManager(ChatContext context)
        {
            _context = context;
        }

        public async Task SaveChatMessage(ChatMessage message)
        {
            _context.ChatMessages.Add(message);
            await _context.SaveChangesAsync();
        }

        public async Task<List<ChatMessage>> GetChatHistory()
        {
            return await _context.ChatMessages.OrderBy(m => m.CreatedOn).ToListAsync();
        }
    }
}
