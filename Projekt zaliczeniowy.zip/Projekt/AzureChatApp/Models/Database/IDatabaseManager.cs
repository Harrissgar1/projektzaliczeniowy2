﻿using AzureChatApp.Models.Chat;

namespace AzureChatApp.Models.Database
{
    public interface IDatabaseManager
    {
        Task SaveChatMessage(ChatMessage message);
        Task<List<ChatMessage>> GetChatHistory();
    }
}
