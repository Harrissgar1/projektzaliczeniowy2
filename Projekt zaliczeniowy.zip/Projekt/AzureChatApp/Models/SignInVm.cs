﻿using System.ComponentModel.DataAnnotations;

namespace AzureChatApp.Models;

public class SignInVm
{
    [Required]
    public string Username { get; set; }
}


