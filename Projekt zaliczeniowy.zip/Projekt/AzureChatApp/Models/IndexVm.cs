﻿namespace AzureChatApp.Models
{
    public class IndexVm
    {
        public string Username {  get; set; }
    }
}
